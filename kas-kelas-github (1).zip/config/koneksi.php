<?php
$conn = mysqli_connect("localhost","root","","kas_kelas");
?>
